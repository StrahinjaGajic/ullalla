<?php

return [

    #locals

    'text_area' => 'Text Area',
    'n_a' => 'N / A',
    'free' => 'Free',
    'with_cost' => 'With Cost',
    'wellness' => 'Wellness',
    'entrance' => 'Entrance',
    'yes' => 'Yes',
    'no' => 'No',
    'food_and_drinks' => 'Food and Drinks',
    'outdoor_area' => 'Outdoor Area',

    'username' => 'Username',
    'surname' => 'Surname',
    'email' => 'E-mail',
    'password' => 'Password',
    'confirm_password' => 'Confirm Password',
    'name' => 'Name',
    'street' => 'Street',
    'phone' => 'Phone',
    'city' => 'City',
    'web' => 'Web',
    'zip' => 'Zip',
    'available_24_7' => 'Available 24/7',
    'mark_all' => 'Mark All',
    'about_us' => 'About Us',
    'local_type' => 'Local Type',
    'manage_user' => 'Manage User',
    'subject' => 'Subject',
    'comment' => 'Comment',
    'required_fields' => 'Required Fields',
];