<?php
return [
    #locals-single
    'entrance' => 'Entrance',
    'wellness' => 'Wellness',
    'food_and_drinks' => 'Food and Drinks',
    'outdoor_area' => 'Outdoor Area',

    #locals
    'month' => 'Month',
    'year' => 'Year',

];
?>